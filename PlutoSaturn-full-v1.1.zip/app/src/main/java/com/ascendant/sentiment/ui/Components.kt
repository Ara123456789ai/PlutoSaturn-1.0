package com.ascendant.sentiment.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascendant.sentiment.engine.AstroEngine
import com.ascendant.sentiment.model.*
import com.ascendant.sentiment.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

@Composable
fun SentimentGaugeCard(
    currentBar: SentimentBar?,
    locationName: String,
    timeZoneId: String,
    orbLimit: Double
) {
    if (currentBar == null) return

    val score = currentBar.sentimentScore
    val isBull = score > 0.15
    val isBear = score < -0.15
    val statusText = if (isBull) "BULLISH" else if (isBear) "BEARISH" else "NEUTRAL"
    val statusColor = if (isBull) Emerald400 else if (isBear) Rose400 else Slate400
    val statusBg = if (isBull) Emerald500.copy(alpha = 0.15f) else if (isBear) Rose500.copy(alpha = 0.15f) else Slate800

    val sdf = SimpleDateFormat("EEE, dd MMM HH:mm", Locale.US).apply {
        timeZone = TimeZone.getTimeZone(timeZoneId)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SENTIMENT INDEX S",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate400,
                    letterSpacing = 1.sp
                )

                Surface(
                    color = statusBg,
                    shape = RoundedCornerShape(20.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(statusColor.copy(alpha = 0.5f)))
                ) {
                    Text(
                        text = statusText,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = if (score > 0) "+%.3f".format(score) else "%.3f".format(score),
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = statusColor
                )

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = sdf.format(Date(currentBar.timeMs)),
                        fontSize = 12.sp,
                        color = Slate100,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "ASC " + AstroEngine.formatDMS(currentBar.ascDegree),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Emerald400,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = locationName,
                        fontSize = 10.sp,
                        color = Slate400
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visual Meter Bar
            val clampedScore = score.coerceIn(-1.0, 1.0)
            val fraction = ((clampedScore + 1.0) / 2.0).toFloat()

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Slate950)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction)
                        .background(if (isBull) Emerald500 else if (isBear) Rose500 else Slate400)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("−1.0 Bearish", fontSize = 9.sp, color = Slate400)
                Text("0.0 Neutral", fontSize = 9.sp, color = Slate400)
                Text("+1.0 Bullish", fontSize = 9.sp, color = Slate400)
            }
        }
    }
}

private val HardPlutoMagenta = Color(0xFFFF00FF)

/**
 * Active Ascendant Aspects list (v3.6: now shown in a card below the Midheaven box).
 */
@Composable
fun ActiveAspectsLayer(aspects: List<AspectInfo>, modifier: Modifier = Modifier, compact: Boolean = false) {
    val sorted = aspects.sortedByDescending { abs(it.contribution) }

    Column(
        modifier = modifier
            .padding(
                start = if (compact) 12.dp else 46.dp,
                end = if (compact) 12.dp else 16.dp,
                top = if (compact) 12.dp else 14.dp,
                bottom = if (compact) 12.dp else 28.dp
            )
    ) {
        Text(
            text = "ACTIVE ASCENDANT ASPECTS (${aspects.size})",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Slate100
        )

        Spacer(modifier = Modifier.height(4.dp))

        if (sorted.isEmpty()) {
            Text(
                text = "No aspects within orb limit at this moment",
                fontSize = 11.sp,
                color = Slate400,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        } else {
            sorted.forEach { aspect ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .background(BgDark.copy(alpha = 0.72f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = aspect.glyph,
                            fontSize = 15.sp,
                            color = if (aspect.isHardPluto) HardPlutoMagenta else Amber500,
                            modifier = Modifier.width(22.dp)
                        )
                        Text(
                            text = "${aspect.planetName} ${aspect.aspectAngle}°",
                            fontSize = 12.sp,
                            fontWeight = if (aspect.isHardPluto) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (aspect.isHardPluto) HardPlutoMagenta else Slate100
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(orb %.2f°)".format(aspect.orbDiff),
                            fontSize = 10.sp,
                            color = Slate400
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "W %.1f".format(aspect.dynWeight),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Slate400
                        )
                    }

                    val contrib = aspect.contribution
                    Text(
                        text = if (contrib > 0) "+%.2f".format(contrib) else "%.2f".format(contrib),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (contrib > 0) Emerald400 else Rose400
                    )
                }
            }
        }
    }
}

/**
 * v3.2: Active Midheaven Aspects, the Midheaven against the fixed birth chart points.
 */
@Composable
fun ActiveMidheavenCard(currentBar: SentimentBar?) {
    if (currentBar == null) return

    val aspects = currentBar.mcAspects
    val sorted = aspects.sortedByDescending { abs(it.contribution) }
    val mcScore = currentBar.mcScore
    val scoreColor = if (mcScore > 0.15) Emerald400 else if (mcScore < -0.15) Rose400 else Slate400

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE MIDHEAVEN ASPECTS (${aspects.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate100
                )
                Text(
                    text = "MC index " + (if (mcScore > 0) "+%.2f".format(mcScore) else "%.2f".format(mcScore)),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = scoreColor
                )
            }
            Text(
                text = "Midheaven " + AstroEngine.formatDMS(currentBar.mcDegree) + "  vs birth chart",
                fontSize = 10.sp,
                color = Slate400,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (sorted.isEmpty()) {
                Text(
                    text = "No birth chart point within orb of the Midheaven at this moment",
                    fontSize = 11.sp,
                    color = Slate400,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            } else {
                sorted.forEach { aspect ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = aspect.glyph,
                                fontSize = 15.sp,
                                color = if (aspect.isHardPluto) HardPlutoMagenta else Amber500,
                                modifier = Modifier.width(22.dp)
                            )
                            Text(
                                text = "Natal ${aspect.planetName} ${aspect.aspectAngle}°",
                                fontSize = 12.sp,
                                fontWeight = if (aspect.isHardPluto) FontWeight.Bold else FontWeight.SemiBold,
                                color = if (aspect.isHardPluto) HardPlutoMagenta else Slate100
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "(orb %.2f°)".format(aspect.orbDiff),
                                fontSize = 10.sp,
                                color = Slate400
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "W %.1f".format(aspect.dynWeight),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Slate400
                            )
                        }

                        val contrib = aspect.contribution
                        Text(
                            text = if (contrib > 0) "+%.2f".format(contrib) else "%.2f".format(contrib),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (contrib > 0) Emerald400 else Rose400
                        )
                    }
                }
            }
        }
    }
}

/**
 * v3.6: Resonance list, drawn as the opaque FRONT layer over the faded bar chart.
 * A planet is resonant when it appears in both the Active Ascendant and Active Midheaven lists.
 */
@Composable
fun ResonanceLayer(currentBar: SentimentBar?, showMc: Boolean, modifier: Modifier = Modifier) {
    val ascByPlanet = currentBar?.aspects.orEmpty().groupBy { it.planetName }
    val mcByPlanet = currentBar?.mcAspects.orEmpty().groupBy { it.planetName }
    val resonant = ascByPlanet.keys.filter { it in mcByPlanet }
        .sortedByDescending { p ->
            (ascByPlanet[p].orEmpty() + mcByPlanet[p].orEmpty()).sumOf { abs(it.contribution) }
        }

    Column(modifier = modifier.padding(start = 46.dp, end = 16.dp, top = 14.dp, bottom = 28.dp)) {
        Text(
            text = "RESONANCE (${if (showMc) resonant.size else 0})",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Slate100
        )
        Text(
            text = "Planets active on both the Ascendant and the Midheaven",
            fontSize = 10.sp,
            color = Slate400,
            modifier = Modifier.padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))

        if (!showMc) {
            Text(
                text = "Turn on the MC birth chart overlay to see resonance",
                fontSize = 11.sp,
                color = Slate400,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        } else if (resonant.isEmpty()) {
            Text(
                text = "No resonant planets at this moment",
                fontSize = 11.sp,
                color = Slate400,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        } else {
            resonant.forEach { planet ->
                val asc = ascByPlanet[planet].orEmpty()
                val mc = mcByPlanet[planet].orEmpty()
                val glyph = asc.firstOrNull()?.glyph ?: ""
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .background(BgDark.copy(alpha = 0.72f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 3.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = glyph,
                            fontSize = 15.sp,
                            color = Amber500,
                            modifier = Modifier.width(22.dp)
                        )
                        Text(
                            text = "$planet is resonant",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Amber500
                        )
                    }
                    Text(
                        text = "Ascendant: " + asc.joinToString(", ") { "${it.aspectAngle}°" },
                        fontSize = 11.sp,
                        color = Slate100,
                        modifier = Modifier.padding(start = 22.dp)
                    )
                    Text(
                        text = "Midheaven: " + mc.joinToString(", ") { "${it.aspectAngle}° (natal ${it.planetName})" },
                        fontSize = 11.sp,
                        color = Slate100,
                        modifier = Modifier.padding(start = 22.dp)
                    )
                }
            }
        }
    }
}

/** v3.6: the Active Ascendant Aspects list as a normal card (sits below the Midheaven box). */
@Composable
fun ActiveAscendantCard(currentBar: SentimentBar?) {
    if (currentBar == null) return
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
    ) {
        ActiveAspectsLayer(
            aspects = currentBar.aspects,
            modifier = Modifier.fillMaxWidth(),
            compact = true
        )
    }
}

@Composable
fun ExactHitsCard(
    hits: List<HitEvent>,
    timeZoneId: String,
    onJumpToHit: (Long) -> Unit
) {
    val sdf = SimpleDateFormat("HH:mm", Locale.US).apply {
        timeZone = TimeZone.getTimeZone(timeZoneId)
    }
    val now = System.currentTimeMillis()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "EXACT ASCENDANT HITS IN WINDOW (${hits.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Slate100
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (hits.isEmpty()) {
                Text(
                    text = "None in window",
                    fontSize = 11.sp,
                    color = Slate400,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            } else {
                hits.forEach { hit ->
                    val isPast = hit.timeMs < now
                    val diffMin = ((hit.timeMs - now) / 60000).toInt()
                    val relStr = if (abs(diffMin) <= 3) "NOW" else if (diffMin > 0) "in ${diffMin}m" else "${abs(diffMin)}m ago"

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onJumpToHit(hit.timeMs) }
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = sdf.format(Date(hit.timeMs)),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPast) Slate400 else Slate100
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${hit.glyph} ${hit.planetName} ${hit.aspectAngle}°",
                                fontSize = 12.sp,
                                color = if (isPast) Slate400 else Slate100
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (hit.polarity > 0) "▲ +1" else "▼ −1",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (hit.polarity > 0) Emerald400 else Rose400
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = relStr,
                                fontSize = 10.sp,
                                color = if (relStr == "NOW") Amber500 else Slate400
                            )
                        }
                    }
                    Divider(color = BorderDark.copy(alpha = 0.5f), thickness = 0.5.dp)
                }
            }
        }
    }
}

/**
 * v4.2: Resonance breakdown for the selected bar, in a quiet background style.
 * Lists every transit-to-natal hit that makes up the bull and bear bars, biggest first.
 */
@Composable
fun ResonanceBreakdownCard(currentBar: SentimentBar?) {
    if (currentBar == null) return

    val hits = currentBar.resHits.sortedByDescending { abs(it.value) }
    val maxAbs = hits.maxOfOrNull { abs(it.value) } ?: 1.0
    val shown = hits.take(12)
    val pulseViolet = Color(0xFFA78BFA)

    fun signed(v: Double): String = (if (v > 0) "+" else "") + "%.2f".format(v)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = BgDark),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(BorderDark.copy(alpha = 0.6f))
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "RESONANCE BREAKDOWN (${hits.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Slate400
            )
            Text(
                text = "Bull +%.2f  Bear −%.2f  |  Base %s  Pulse %s".format(
                    currentBar.resBull,
                    currentBar.resBear,
                    signed(currentBar.resBase),
                    signed(currentBar.resPulse)
                ),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Slate400,
                modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )

            if (hits.isEmpty()) {
                Text(
                    text = "No transit-natal aspect within orb on this bar",
                    fontSize = 11.sp,
                    color = Slate400,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            } else {
                shown.forEach { h ->
                    val v = h.value
                    val col = if (v > 0) Emerald400 else Rose400
                    val tags = buildList {
                        if (h.ascTrigger) add("ASC")
                        if (h.mcTrigger) add("MC")
                        if (h.pairMult > 1.0) add("PAIR")
                    }
                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${h.transitGlyph} ${h.transitName} ${h.aspectAngle}° natal ${h.natalGlyph} ${h.natalName}",
                                fontSize = 11.sp,
                                color = Slate100.copy(alpha = 0.85f),
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = signed(v),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = col
                            )
                        }
                        Text(
                            text = "orb %.1f°  Wp %.2f  Cj %.3f  ×%.2f".format(
                                h.orbDiff, h.dynWeight, h.coeff, h.orbFactor * h.boost
                            ) + if (tags.isEmpty()) "" else "   " + tags.joinToString(" "),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (tags.isEmpty()) Slate400 else pulseViolet.copy(alpha = 0.9f)
                        )
                        Box(
                            modifier = Modifier
                                .padding(top = 2.dp)
                                .fillMaxWidth((abs(v) / maxAbs).toFloat().coerceIn(0.02f, 1f))
                                .height(3.dp)
                                .background(col.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
                        )
                    }
                }
                if (hits.size > shown.size) {
                    Text(
                        text = "+ ${hits.size - shown.size} smaller hits",
                        fontSize = 10.sp,
                        color = Slate400,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}
